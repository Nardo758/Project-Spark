# Google Maps Scraper - Industry Pattern Integration Guide

## Quick Implementation Checklist

- [ ] Update `google_maps_scraper.py` with business category detection
- [ ] Import new industry pattern matrix
- [ ] Modify `analyze_review()` function
- [ ] Add rating weight calculation
- [ ] Add engagement multipliers
- [ ] Add quantification boost detection
- [ ] Test on sample reviews
- [ ] Deploy to production

---

## Step 1: Install Dependencies (if needed)

```bash
pip install selenium webdriver-manager requests --break-system-packages
```

---

## Step 2: Update Google Maps Scraper - Business Category Detection

**File:** `google_maps_scraper.py`

### Add Business Category Extraction

```python
# Add this function after imports
def extract_business_category(driver) -> str:
    """
    Extract Google Maps business category
    Examples: "Apartment complex", "Restaurant", "Day care center"
    """
    try:
        # Try multiple selectors for category
        category_selectors = [
            "button[jsaction*='category']",
            "button.DkEaL",  # Category button class
            "div[aria-label*='Categories']"
        ]
        
        for selector in category_selectors:
            try:
                category_element = driver.find_element(By.CSS_SELECTOR, selector)
                return category_element.text.strip()
            except:
                continue
        
        # Fallback: look in structured data
        script_tags = driver.find_elements(By.CSS_SELECTOR, "script[type='application/ld+json']")
        for script in script_tags:
            try:
                data = json.loads(script.get_attribute('textContent'))
                if '@type' in data:
                    return data.get('@type', 'unknown')
            except:
                continue
                
        return 'unknown'
        
    except Exception as e:
        print(f"Could not extract business category: {e}")
        return 'unknown'
```

### Update Main Scraper to Capture Business Info

```python
def scrape_google_maps_reviews(place_url: str) -> List[Dict]:
    """Scrape reviews from Google Maps place with industry classification"""
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    
    driver = webdriver.Chrome(options=options)
    reviews = []
    
    try:
        driver.get(place_url)
        time.sleep(3)
        
        # ===== NEW: Extract business information =====
        business_name = extract_business_name(driver)
        business_type = extract_business_category(driver)
        business_address = extract_business_address(driver)
        
        print(f"Scraping: {business_name}")
        print(f"Category: {business_type}")
        print(f"Address: {business_address}")
        # ============================================
        
        # Click reviews tab
        try:
            reviews_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Reviews')]"))
            )
            reviews_button.click()
            time.sleep(2)
        except:
            return reviews
        
        # Scroll to load reviews
        scrollable = driver.find_element(By.CSS_SELECTOR, "div[role='main']")
        for _ in range(5):
            driver.execute_script('arguments[0].scrollTop = arguments[0].scrollHeight', scrollable)
            time.sleep(1)
        
        # Extract reviews
        review_elements = driver.find_elements(By.CSS_SELECTOR, "div.jftiEf")
        
        for element in review_elements:
            try:
                author = element.find_element(By.CSS_SELECTOR, "div.d4r55").text
                rating = len(element.find_elements(By.CSS_SELECTOR, "span.hCCjke.google-symbols"))
                text = element.find_element(By.CSS_SELECTOR, "span.wiI7pd").text
                date = element.find_element(By.CSS_SELECTOR, "span.rsqaWe").text
                
                # NEW: Try to get "useful" vote count
                try:
                    useful_element = element.find_element(By.CSS_SELECTOR, "button[aria-label*='helpful']")
                    useful_text = useful_element.get_attribute('aria-label')
                    # Extract number from "123 people found this review helpful"
                    useful_count = int(re.search(r'(\d+)', useful_text).group(1))
                except:
                    useful_count = 0
                
                # NEW: Check if review has photos
                has_photos = len(element.find_elements(By.CSS_SELECTOR, "button[jsaction*='photo']")) > 0
                
                # ===== NEW: Analyze with industry patterns =====
                review_data = {
                    'text': text,
                    'rating': rating,
                    'business_name': business_name,
                    'business_type': business_type,
                    'useful_count': useful_count,
                    'has_photos': has_photos
                }
                
                analysis = analyze_review_with_industry_patterns(review_data)
                # ==============================================
                
                # Only keep high-signal reviews (score >= 0.70)
                if analysis['signal_score'] >= 0.70:
                    reviews.append({
                        'source': 'google_maps',
                        'author': author,
                        'rating': rating,
                        'text': text,
                        'date': date,
                        'useful_count': useful_count,
                        'has_photos': has_photos,
                        'business_name': business_name,
                        'business_type': business_type,
                        'business_address': business_address,
                        'url': place_url,
                        # NEW fields from analysis
                        'signal_score': analysis['signal_score'],
                        'industry': analysis['industry'],
                        'problem_category': analysis.get('category'),
                        'opportunities': analysis.get('opportunities', []),
                        'pattern_matches': analysis.get('matches', [])
                    })
            except Exception as e:
                print(f"Error processing review: {e}")
                continue
                
    finally:
        driver.quit()
    
    return reviews


# Helper functions for business data extraction
def extract_business_name(driver) -> str:
    """Extract business name from Google Maps"""
    try:
        name_element = driver.find_element(By.CSS_SELECTOR, "h1.DUwDvf")
        return name_element.text.strip()
    except:
        return "Unknown Business"

def extract_business_address(driver) -> str:
    """Extract business address from Google Maps"""
    try:
        address_element = driver.find_element(By.CSS_SELECTOR, "button[data-item-id='address']")
        return address_element.get_attribute('aria-label').replace('Address: ', '')
    except:
        return "Unknown Address"
```

---

## Step 3: Create New Analysis Function

**File:** `google_maps_scraper.py` (add after helper functions)

```python
import re
from google_maps_keyword_matrix import (
    classify_business_category,
    get_industry_patterns,
    RATING_WEIGHTS,
    ENGAGEMENT_BOOSTS,
    QUANTIFICATION_BOOSTS
)

def analyze_review_with_industry_patterns(review: dict) -> dict:
    """
    Analyze review using industry-specific patterns
    
    Args:
        review: {
            'text': str,
            'rating': int (1-5),
            'business_name': str,
            'business_type': str,
            'useful_count': int,
            'has_photos': bool
        }
    
    Returns:
        {
            'signal_score': float (0.0-1.0),
            'industry': str,
            'category': str,
            'matches': list of pattern matches,
            'opportunities': list of opportunity types
        }
    """
    
    # Step 1: Classify industry
    industry = classify_business_category(
        review['business_name'],
        review.get('business_type', 'unknown')
    )
    
    # Step 2: Get industry-specific patterns
    patterns = get_industry_patterns(industry)
    
    # Step 3: Pattern matching
    text_lower = review['text'].lower()
    matches = []
    max_base_score = 0.0
    primary_category = None
    opportunities = []
    
    for pattern_name, pattern_data in patterns.items():
        for pattern in pattern_data['patterns']:
            if re.search(pattern, text_lower):
                confidence = pattern_data['confidence']
                if confidence > max_base_score:
                    max_base_score = confidence
                    primary_category = pattern_data.get('category')
                
                matches.append({
                    'pattern': pattern_name,
                    'confidence': confidence,
                    'category': pattern_data.get('category'),
                    'signal_type': pattern_data.get('signal_type')
                })
                
                # Collect opportunity types
                opp = pattern_data.get('opportunity_extraction')
                if opp and opp not in opportunities:
                    opportunities.append(opp)
    
    # If no patterns matched, return zero signal
    if max_base_score == 0.0:
        return {
            'signal_score': 0.0,
            'industry': industry,
            'category': 'none',
            'matches': [],
            'opportunities': []
        }
    
    # Step 4: Apply rating weight
    rating = review.get('rating', 3)
    rating_weight = RATING_WEIGHTS.get(rating, 0.5)
    weighted_score = max_base_score * rating_weight
    
    # Step 5: Apply engagement multipliers
    useful_count = review.get('useful_count', 0)
    if useful_count >= ENGAGEMENT_BOOSTS['high_engagement']['threshold']:
        weighted_score *= ENGAGEMENT_BOOSTS['high_engagement']['multiplier']
    elif useful_count >= ENGAGEMENT_BOOSTS['medium_engagement']['threshold']:
        weighted_score *= ENGAGEMENT_BOOSTS['medium_engagement']['multiplier']
    
    # Photo evidence boost
    if review.get('has_photos', False):
        weighted_score *= ENGAGEMENT_BOOSTS['photo_attached']['multiplier']
    
    # Step 6: Apply quantification boosts
    text = review['text']
    
    # Dollar amount boost
    if re.search(QUANTIFICATION_BOOSTS['dollar_amount']['pattern'], text):
        weighted_score *= QUANTIFICATION_BOOSTS['dollar_amount']['multiplier']
    
    # Time amount boost
    if re.search(QUANTIFICATION_BOOSTS['time_amount']['pattern'], text):
        weighted_score *= QUANTIFICATION_BOOSTS['time_amount']['multiplier']
    
    # Frequency boost
    for pattern in QUANTIFICATION_BOOSTS['frequency']['patterns']:
        if re.search(pattern, text_lower):
            weighted_score *= QUANTIFICATION_BOOSTS['frequency']['multiplier']
            break
    
    # Cap at 1.0
    final_score = min(weighted_score, 1.0)
    
    return {
        'signal_score': final_score,
        'industry': industry,
        'category': primary_category,
        'matches': matches,
        'opportunities': opportunities,
        'rating_weight': rating_weight,
        'engagement_boost': useful_count >= 5,
        'has_quantification': bool(re.search(r"\$\d+|\d+\s+(months?|weeks?|hours?)", text))
    }
```

---

## Step 4: Update Database Schema (Optional but Recommended)

**Add new columns to scraped_reviews table:**

```sql
ALTER TABLE scraped_reviews
ADD COLUMN business_name VARCHAR(500),
ADD COLUMN business_type VARCHAR(200),
ADD COLUMN business_address VARCHAR(500),
ADD COLUMN industry VARCHAR(100),
ADD COLUMN problem_category VARCHAR(200),
ADD COLUMN signal_type VARCHAR(200),
ADD COLUMN opportunities JSONB,
ADD COLUMN pattern_matches JSONB,
ADD COLUMN useful_count INTEGER DEFAULT 0,
ADD COLUMN has_photos BOOLEAN DEFAULT FALSE,
ADD COLUMN rating_weight FLOAT,
ADD COLUMN has_quantification BOOLEAN DEFAULT FALSE;

-- Index for industry-based filtering
CREATE INDEX idx_scraped_reviews_industry ON scraped_reviews(industry);
CREATE INDEX idx_scraped_reviews_category ON scraped_reviews(problem_category);
```

---

## Step 5: Test with Sample Data

**Create test file:** `test_industry_patterns.py`

```python
from google_maps_scraper import analyze_review_with_industry_patterns

# Test 1: Apartment parking complaint
apartment_review = {
    'text': 'New guest parking policy is very disappointing. Guests now have to pay $5 every single time just to park in the garage. It used to be much more reasonable.',
    'rating': 2,
    'business_name': 'Indigo West Palm Beach',
    'business_type': 'Apartment complex',
    'useful_count': 15,
    'has_photos': False
}

result = analyze_review_with_industry_patterns(apartment_review)
print(f"\n=== Apartment Review Test ===")
print(f"Signal Score: {result['signal_score']:.2f}")
print(f"Industry: {result['industry']}")
print(f"Category: {result['category']}")
print(f"Opportunities: {result['opportunities']}")
print(f"Matches: {len(result['matches'])} patterns")

# Test 2: Childcare waitlist
childcare_review = {
    'text': '18-month waitlist for infant care. Can\'t get a spot anywhere. This is ridiculous.',
    'rating': 1,
    'business_name': 'Bright Horizons Daycare',
    'business_type': 'Day care center',
    'useful_count': 8,
    'has_photos': False
}

result = analyze_review_with_industry_patterns(childcare_review)
print(f"\n=== Childcare Review Test ===")
print(f"Signal Score: {result['signal_score']:.2f}")
print(f"Industry: {result['industry']}")
print(f"Category: {result['category']}")
print(f"Opportunities: {result['opportunities']}")

# Test 3: Restaurant reservation
restaurant_review = {
    'text': 'Impossible to get reservations on weekends - booked 6 weeks out. Great food but the wait is insane.',
    'rating': 3,
    'business_name': 'The French Laundry',
    'business_type': 'Restaurant',
    'useful_count': 12,
    'has_photos': True
}

result = analyze_review_with_industry_patterns(restaurant_review)
print(f"\n=== Restaurant Review Test ===")
print(f"Signal Score: {result['signal_score']:.2f}")
print(f"Industry: {result['industry']}")
print(f"Category: {result['category']}")
print(f"Opportunities: {result['opportunities']}")

# Test 4: Positive review (should be ignored)
positive_review = {
    'text': 'Amazing service, beautiful location, highly recommend!',
    'rating': 5,
    'business_name': 'Any Business',
    'business_type': 'Restaurant',
    'useful_count': 50,
    'has_photos': True
}

result = analyze_review_with_industry_patterns(positive_review)
print(f"\n=== Positive Review Test (Should Score 0) ===")
print(f"Signal Score: {result['signal_score']:.2f}")
```

**Expected output:**

```
=== Apartment Review Test ===
Signal Score: 1.00
Industry: apartment
Category: policy_friction
Opportunities: ['fee_elimination_service']
Matches: 2 patterns

=== Childcare Review Test ===
Signal Score: 0.99
Industry: childcare
Category: supply_shortage
Opportunities: ['childcare_marketplace']

=== Restaurant Review Test ===
Signal Score: 0.70
Industry: restaurant
Category: access_friction
Opportunities: ['reservation_aggregator']

=== Positive Review Test (Should Score 0) ===
Signal Score: 0.00
```

---

## Step 6: Run Test on Sample Business

**Test on Indigo apartments:**

```python
# test_indigo.py
from google_maps_scraper import scrape_google_maps_reviews

place_url = "https://www.google.com/maps/place/Indigo+West+Palm+Beach"

reviews = scrape_google_maps_reviews(place_url)

print(f"\n=== Indigo West Palm Beach Results ===")
print(f"Total reviews processed: {len(reviews)}")
print(f"\nHigh-signal reviews (>= 0.70):")

for review in sorted(reviews, key=lambda x: x['signal_score'], reverse=True):
    print(f"\nScore: {review['signal_score']:.2f}")
    print(f"Rating: {review['rating']} stars")
    print(f"Category: {review['problem_category']}")
    print(f"Text: {review['text'][:100]}...")
    print(f"Opportunities: {review['opportunities']}")
```

---

## Step 7: Integration with Existing Database

**File:** `save_to_database.py` (update existing function)

```python
def save_review_to_database(review: dict):
    """Save review with industry analysis to database"""
    
    conn = psycopg2.connect(
        host=os.getenv('DB_HOST'),
        dbname=os.getenv('DB_NAME'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD')
    )
    
    cursor = conn.cursor()
    
    # Insert with new fields
    cursor.execute("""
        INSERT INTO scraped_reviews (
            source, author, rating, review_text, review_date,
            business_name, business_type, business_address,
            source_url, signal_score, 
            industry, problem_category, signal_type,
            opportunities, pattern_matches,
            useful_count, has_photos, rating_weight,
            has_quantification, created_at
        ) VALUES (
            %s, %s, %s, %s, %s,
            %s, %s, %s,
            %s, %s,
            %s, %s, %s,
            %s, %s,
            %s, %s, %s,
            %s, NOW()
        )
    """, (
        review['source'],
        review['author'],
        review['rating'],
        review['text'],
        review['date'],
        review['business_name'],
        review['business_type'],
        review['business_address'],
        review['url'],
        review['signal_score'],
        review['industry'],
        review['problem_category'],
        review.get('signal_type'),
        json.dumps(review.get('opportunities', [])),
        json.dumps(review.get('pattern_matches', [])),
        review.get('useful_count', 0),
        review.get('has_photos', False),
        review.get('rating_weight', 0.0),
        review.get('has_quantification', False)
    ))
    
    conn.commit()
    cursor.close()
    conn.close()
```

---

## Step 8: Performance Comparison

**Before vs After on same dataset:**

```python
# comparison_test.py
from old_google_maps_scraper import scrape_google_maps_reviews as old_scraper
from google_maps_scraper import scrape_google_maps_reviews as new_scraper

place_url = "https://www.google.com/maps/place/Indigo+West+Palm+Beach"

print("Running OLD scraper...")
old_results = old_scraper(place_url)

print("Running NEW scraper...")
new_results = new_scraper(place_url)

print(f"\n=== Comparison ===")
print(f"Old system detected: {len(old_results)} high-signal reviews")
print(f"New system detected: {len(new_results)} high-signal reviews")
print(f"Improvement: {((len(new_results) - len(old_results)) / len(old_results) * 100):.1f}%")

print(f"\n=== Signal Quality Distribution ===")
old_goldmine = sum(1 for r in old_results if r['signal_score'] >= 0.90)
new_goldmine = sum(1 for r in new_results if r['signal_score'] >= 0.90)

print(f"GOLDMINE (>= 0.90):")
print(f"  Old: {old_goldmine}")
print(f"  New: {new_goldmine}")

print(f"\n=== Top Opportunities (New System) ===")
opportunities = {}
for review in new_results:
    for opp in review.get('opportunities', []):
        opportunities[opp] = opportunities.get(opp, 0) + 1

for opp, count in sorted(opportunities.items(), key=lambda x: x[1], reverse=True):
    print(f"{opp}: {count} reviews")
```

---

## Step 9: Production Deployment

**Update main scraper runner:**

```python
# run_scrapers.py
from google_maps_scraper import scrape_google_maps_reviews

# Target businesses by industry
APARTMENT_TARGETS = [
    "https://www.google.com/maps/place/Indigo+West+Palm+Beach",
    "https://www.google.com/maps/place/Modera+44",
    # ... more apartments
]

CHILDCARE_TARGETS = [
    "https://www.google.com/maps/place/Bright+Horizons",
    # ... more daycares
]

RESTAURANT_TARGETS = [
    "https://www.google.com/maps/place/The+French+Laundry",
    # ... more restaurants
]

def run_all_industries():
    all_reviews = []
    
    print("Scraping apartments...")
    for url in APARTMENT_TARGETS:
        reviews = scrape_google_maps_reviews(url)
        all_reviews.extend(reviews)
        print(f"  Found {len(reviews)} signals")
    
    print("\nScraping childcare...")
    for url in CHILDCARE_TARGETS:
        reviews = scrape_google_maps_reviews(url)
        all_reviews.extend(reviews)
        print(f"  Found {len(reviews)} signals")
    
    print("\nScraping restaurants...")
    for url in RESTAURANT_TARGETS:
        reviews = scrape_google_maps_reviews(url)
        all_reviews.extend(reviews)
        print(f"  Found {len(reviews)} signals")
    
    print(f"\n=== Total Results ===")
    print(f"Total high-signal reviews: {len(all_reviews)}")
    
    # Save to database
    for review in all_reviews:
        save_review_to_database(review)
    
    print("Done! Saved to database.")

if __name__ == "__main__":
    run_all_industries()
```

---

## Step 10: Monitoring Dashboard

**Query for validation:**

```sql
-- Signal distribution by industry
SELECT 
    industry,
    COUNT(*) as total_reviews,
    AVG(signal_score) as avg_score,
    COUNT(CASE WHEN signal_score >= 0.90 THEN 1 END) as goldmine_count
FROM scraped_reviews
WHERE created_at >= NOW() - INTERVAL '7 days'
GROUP BY industry
ORDER BY goldmine_count DESC;

-- Top opportunities by industry
SELECT 
    industry,
    problem_category,
    COUNT(*) as review_count,
    AVG(signal_score) as avg_score
FROM scraped_reviews
WHERE signal_score >= 0.70
GROUP BY industry, problem_category
ORDER BY review_count DESC
LIMIT 20;

-- Most validated opportunities (multiple reviews same opportunity)
SELECT 
    business_name,
    problem_category,
    COUNT(*) as complaint_count,
    AVG(signal_score) as avg_score,
    STRING_AGG(DISTINCT opportunities::text, ', ') as opportunity_types
FROM scraped_reviews
WHERE signal_score >= 0.70
GROUP BY business_name, problem_category
HAVING COUNT(*) >= 3  -- At least 3 reviews complaining about same thing
ORDER BY complaint_count DESC, avg_score DESC;
```

---

## Expected Results After Implementation

### Indigo West Palm Beach - Before

- **Total reviews scraped:** 50
- **High-signal detected:** 5 (10%)
- **Top pattern:** "terrible" (generic)
- **Opportunities:** Vague parking complaints

### Indigo West Palm Beach - After

- **Total reviews scraped:** 50
- **High-signal detected:** 12 (24%)
- **Top patterns:** 
  - "new policy" → 3 reviews (guest parking)
  - "water smells" → 2 reviews (sulfur)
  - "takes forever" → 2 reviews (maintenance)
- **Validated opportunities:**
  1. Guest parking fee elimination (3 reviews, avg score 0.95)
  2. Water quality testing (2 reviews, avg score 0.78)
  3. Maintenance tracking app (2 reviews, avg score 0.72)

---

## Troubleshooting

### Issue: Low detection rates

**Solution:** Check if business_type is being extracted correctly

```python
# Debug extraction
driver.get(place_url)
business_type = extract_business_category(driver)
print(f"Detected category: {business_type}")
```

### Issue: Wrong industry classification

**Solution:** Add industry-specific keywords to classifier

```python
# In google_maps_keyword_matrix.py, update classify_business_category()
# Add more keywords to category_map
```

### Issue: Scores too high/low

**Solution:** Adjust multipliers

```python
# In google_maps_keyword_matrix.py
RATING_WEIGHTS = {
    1: 1.0,
    2: 0.80,  # Reduce from 0.85 if too many weak signals
    3: 0.50,  # Reduce from 0.60
    # ...
}
```

---

## Next Steps After Implementation

1. **Validate detection quality** - Manual review of 100 classified reviews
2. **Tune multipliers** - Adjust based on false positive rate
3. **Expand industry patterns** - Add fitness, retail, healthcare subcategories
4. **Add competitor extraction** - Parse "switched to X" patterns
5. **Geographic clustering** - Identify opportunity density by neighborhood
6. **Trend detection** - Track pattern frequency over time

---

## Success Metrics

**After 1 week of production:**

- [ ] 2x increase in high-signal review detection
- [ ] 80%+ reviews correctly classified by industry
- [ ] 50+ validated opportunities (3+ reviews each)
- [ ] < 10% false positive rate on manual review
- [ ] Business-specific opportunities extracted (not generic)

---

## Files Modified/Created

```
oppgrid/
├── scrapers/
│   ├── google_maps_scraper.py          # Modified - added industry analysis
│   ├── google_maps_keyword_matrix.py    # New - industry patterns
│   └── save_to_database.py             # Modified - new fields
├── tests/
│   ├── test_industry_patterns.py       # New - unit tests
│   └── test_indigo.py                  # New - integration test
└── docs/
    ├── google_maps_pattern_recalibration_analysis.md  # New - analysis
    └── implementation_guide.md          # This file
```

Implementation complete! You're now ready to detect industry-specific problems from Google Maps reviews with 2-3x higher signal quality.
