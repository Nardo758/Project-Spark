# OppGrid Complete User Flow & Workhub Design
## From Discovery to Execution

---

## Table of Contents
1. [Overview](#overview)
2. [Discovery Phase: Idea Card Interaction](#discovery-phase)
3. [Transition: Card to Workhub](#transition-flow)
4. [Workhub (Build/Consultant Studio)](#workhub-architecture)
5. [Execution Phase](#execution-phase)
6. [Navigation & State Management](#navigation-state)
7. [Technical Implementation](#technical-implementation)

---

## Overview

### User Journey Philosophy
**"From Problem Discovery to Business Launch in One Platform"**

OppGrid transforms validated market problems into executable business plans through three core phases:
1. **Discovery** - Browse and validate opportunities (Discover tab)
2. **Planning** - Build comprehensive business strategies (Build/Workhub)
3. **Execution** - Connect with resources and launch (Find Help/Money + Manage)

---

## Discovery Phase: Idea Card Interaction

### 1. Opportunity Card States

Each opportunity card adapts based on:
- User subscription tier (Free, Pro, Business, Enterprise)
- Opportunity age (days since discovery)
- User engagement history (saved, viewed, analyzed)

#### Card Components
```
┌─────────────────────────────────────────────┐
│ [CATEGORY TAG]              [AGE BADGE]     │
│                                             │
│ Opportunity Title                           │
│                                  [89 SCORE] │
│                                             │
│ Brief problem description that truncates... │
│                                             │
│ Validations  Market      Growth   Region    │
│ 234         $50M-$100M   +15.3%   Online    │
│                                             │
│ Medium Competition    Severity: 4/5         │
│                                             │
│ 👥 19 people viewed this week               │
│                                             │
│ [Primary CTA]  [Save to Workhub] [Preview] │
└─────────────────────────────────────────────┘
```

### 2. Primary User Actions

#### Action 1: Save to Workhub (All Tiers)
**Purpose:** Bookmark opportunities for later analysis in Build workspace

**Flow:**
```
User clicks "💾 Save to Workhub"
    ↓
Quick animation (heart fill)
    ↓
Opportunity added to user's Workhub collection
    ↓
Optional: Show collection selector
    ["My Ideas" | "High Priority" | "Research Later"]
    ↓
Success notification: "Saved to Workhub - My Ideas"
    ↓
Card UI updates: "✓ Saved" badge appears
```

**Backend:**
```python
POST /api/opportunities/{id}/save
{
  "collection": "my_ideas",  # default collection
  "tags": ["tech", "saas"],  # optional user tags
  "notes": "Interesting problem in vertical SaaS"
}

Response:
{
  "saved": true,
  "workhub_url": "/build/my-ideas/opp-{id}",
  "collection_count": 12
}
```

#### Action 2: View Details (Tier-Dependent)
**Purpose:** Access full opportunity analysis

**Free Tier (91+ day opportunities):**
- Click "🔓 Unlock for $15"
- Payment modal appears
- Access Layer 1 data (problem overview, basic market context)
- Duration: 30 days access

**Pro Tier (31+ day opportunities):**
- Click "View Problem Details →"
- Instant access to Layer 1 + Layer 2
- No payment required

**Business/Enterprise Tiers:**
- Click "View Deep Dive Analysis →"
- Full access to all layers
- Includes geographic intelligence, lead data

#### Action 3: Quick Actions Menu
```
Click [•••] menu on card:
├─ 💾 Save to Workhub
├─ 🚀 Start Business Plan (→ Consultant Studio)
├─ 📊 View Similar Opportunities
├─ 🔔 Set Price Alert (if locked)
├─ 📤 Share with Team
└─ 🏷️ Add Custom Tags
```

### 3. Opportunity Detail View

When user clicks card or "View Details":

```
┌──────────────────────── OPPORTUNITY DETAIL ─────────────────────┐
│                                                                  │
│ [← Back to Discover]     [💾 Save]  [🚀 Build Plan]  [Share]    │
│                                                                  │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ MONEY & FINANCE                        🔥 3d AGO • NEW      │ │
│ │                                                              │ │
│ │ Difficult to track freelance invoices and payments          │ │
│ │                                                        89    │ │
│ │                                                       Score  │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─── PROBLEM OVERVIEW ────────────────────────────────────────┐ │
│ │ Freelancers and independent contractors struggle with:       │ │
│ │ • Tracking multiple invoices across different clients        │ │
│ │ • Payment status visibility and follow-ups                   │ │
│ │ • Cash flow forecasting                                      │ │
│ │ • Late payment management                                    │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─── MARKET CONTEXT ──────────────────────────────────────────┐ │
│ │ Market Size: $50M-$100M TAM                                  │ │
│ │ Growth Rate: +15.3% YoY                                      │ │
│ │ Competition: Medium (3-5 established players)                │ │
│ │ Geographic: US National, expanding to UK/Canada              │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─── VALIDATION SIGNALS ──────────────────────────────────────┐ │
│ │ 📊 234 user mentions across platforms                        │ │
│ │ 💬 Reddit: 89 discussions (r/freelance, r/entrepreneur)      │ │
│ │ 🗺️ Google Reviews: 67 complaints about existing tools        │ │
│ │ 🏘️ Nextdoor: 45 local business inquiries                     │ │
│ │ ⭐ Yelp: 33 service provider frustrations                    │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─── TARGET DEMOGRAPHICS ─────────────────────────────────────┐ │
│ │ Primary: Freelancers ($50K-$150K annual income)              │ │
│ │ Secondary: Small agencies (2-10 contractors)                 │ │
│ │ Age Range: 25-45                                             │ │
│ │ Tech Savvy: Medium-High                                      │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ ┌─── AI INSIGHTS (DeepSeek Analysis) ─────────────────────────┐ │
│ │ 🎯 Key Opportunity Factors:                                  │ │
│ │ • Recurring revenue potential (SaaS model viable)            │ │
│ │ • Network effects (multi-party payments)                     │ │
│ │ • Clear monetization path ($15-50/mo pricing tested)         │ │
│ │                                                              │ │
│ │ ⚠️ Risk Factors:                                              │ │
│ │ • Stripe/Square integration complexity                       │ │
│ │ • Regulatory compliance (payment processing)                 │ │
│ │ • Customer acquisition cost in crowded market                │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
│ [💡 Similar Opportunities (7)]  [📈 Trend Analysis]             │
│                                                                  │
│ ┌──────────────── PRIMARY ACTIONS ────────────────────────────┐ │
│ │                                                              │ │
│ │  [🚀 Start Business Plan in Consultant Studio]              │ │
│ │                                                              │ │
│ │  [💾 Save to Workhub Collection]  [📊 Export Data (CSV)]    │ │
│ │                                                              │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## Transition Flow: Card to Workhub

### 1. The "Save to Workhub" Action

**Purpose:** Create a persistent workspace for opportunities the user wants to develop

**User Experience:**
```
Discovery Card → Click "💾 Save to Workhub"
                        ↓
            ┌───────────────────────┐
            │  Save to Collection   │
            │                       │
            │ ○ My Ideas (12)       │
            │ ○ High Priority (5)   │
            │ ○ Research Later (8)  │
            │                       │
            │ ➕ New Collection...   │
            │                       │
            │  Add tags (optional): │
            │  [saas, fintech]      │
            │                       │
            │ [Cancel]  [Save]      │
            └───────────────────────┘
                        ↓
            Success: "Saved to My Ideas"
                        ↓
            Card shows "✓ Saved" badge
```

**Backend State:**
```python
# User's saved opportunities
user_workhub = {
    "collections": [
        {
            "id": "col_001",
            "name": "My Ideas",
            "opportunities": [
                {
                    "id": "opp_123",
                    "saved_at": "2025-12-20T14:30:00Z",
                    "tags": ["saas", "fintech"],
                    "status": "saved",  # saved | analyzing | planning | executing
                    "notes": "Promising vertical - check competitor pricing"
                }
            ],
            "count": 12
        }
    ],
    "recent_activity": [...],
    "workspace_projects": [...]
}
```

### 2. Navigation to Workhub

**Entry Points:**

**From Discovery:**
```
User Path 1: Card → "Save" → "View in Workhub" button appears
User Path 2: Card → "🚀 Start Business Plan" → Direct to Consultant Studio
User Path 3: Top Nav → "Build" → Workhub Dashboard
```

**Navigation Bar Update:**
```
BEFORE Save (Discover view):
[Discover] [Consultant Studio] [Leads] [Network] [API]

AFTER Save (authenticated):
[Discover] [Build *] [Find Help] [Find Money] [Manage]
            ↑
    Badge shows saved count: Build (12)
```

### 3. Workhub Entry Animation

**Transition Effect:**
```
User clicks "View in Workhub" or "Build" tab
        ↓
Fade out discovery grid
        ↓
Slide in Workhub dashboard (from right)
        ↓
Highlight the newly saved opportunity
        ↓
Show contextual onboarding (first-time users)
```

---

## Workhub Architecture

### Navigation Structure

The **Build** tab is the primary entry point to the Workhub, which contains:

1. **Saved Opportunities** - Collections and organization
2. **Consultant Studio** - AI-powered business planning
3. **Active Projects** - Ongoing business development
4. **Resources & Templates** - Tools and guides

### Workhub Dashboard Layout

```
┌────────────────────────────────── BUILD WORKHUB ─────────────────────────────┐
│                                                                               │
│ [My Ideas ▾]  [Collections]  [Active Projects]  [Templates]  [Settings]     │
│                                                                               │
│ ┌─── COLLECTIONS ───────────────────────────────────────────────────────────┐│
│ │                                                                            ││
│ │  📁 My Ideas (12)          📁 High Priority (5)      📁 Research Later (8) ││
│ │  ├─ SaaS & Tech (7)        ├─ Market Ready (3)      └─ Long-term (8)     ││
│ │  ├─ Local Services (3)     └─ Funding Needed (2)                          ││
│ │  └─ E-commerce (2)                                                         ││
│ │                                                                            ││
│ │  [➕ New Collection]                                                        ││
│ │                                                                            ││
│ └────────────────────────────────────────────────────────────────────────────┘│
│                                                                               │
│ ┌─── RECENT ACTIVITY ───────────────────────────────────────────────────────┐│
│ │                                                                            ││
│ │  Today                                                                     ││
│ │  • Saved "Freelance invoice tracking" to My Ideas               2h ago    ││
│ │  • Generated business plan for "Smart plant care"               4h ago    ││
│ │                                                                            ││
│ │  Yesterday                                                                 ││
│ │  • Started market analysis for "Voice productivity tool"                  ││
│ │  • Connected with consultant Sarah Chen                                   ││
│ │                                                                            ││
│ └────────────────────────────────────────────────────────────────────────────┘│
│                                                                               │
│ ┌─── MY IDEAS (12) ──────────────────────────────────────────────────────────┐│
│ │                                                                            ││
│ │  Sort by: [Most Recent ▾]  Filter: [All Categories ▾]  View: [●●●] [|||] ││
│ │                                                                            ││
│ │  ┌─────────────────────────────────────────────────────────────────────┐  ││
│ │  │ MONEY & FINANCE                             🔥 3d AGO  ✓ SAVED       │  ││
│ │  │                                                                      │  ││
│ │  │ Freelance invoice tracking                           89 SCORE        │  ││
│ │  │                                                                      │  ││
│ │  │ Status: 📊 Analyzing                                                 │  ││
│ │  │ Tags: saas, fintech                                                  │  ││
│ │  │ Notes: Check competitor pricing models                               │  ││
│ │  │                                                                      │  ││
│ │  │ [📝 Add Notes]  [🚀 Build Plan]  [📊 Market Analysis]  [•••]        │  ││
│ │  └─────────────────────────────────────────────────────────────────────┘  ││
│ │                                                                            ││
│ │  ┌─────────────────────────────────────────────────────────────────────┐  ││
│ │  │ HOME & GARDEN                               ✓ 12d AGO  ✓ SAVED       │  ││
│ │  │                                                                      │  ││
│ │  │ Smart plant care system                             92 SCORE         │  ││
│ │  │                                                                      │  ││
│ │  │ Status: 📋 Planning → Business plan generated                        │  ││
│ │  │ Tags: iot, home-automation, saas                                     │  ││
│ │  │                                                                      │  ││
│ │  │ [📄 View Plan]  [👥 Find Partners]  [💰 Find Funding]  [•••]        │  ││
│ │  └─────────────────────────────────────────────────────────────────────┘  ││
│ │                                                                            ││
│ │  [Load More...]                                                            ││
│ │                                                                            ││
│ └────────────────────────────────────────────────────────────────────────────┘│
│                                                                               │
│ ┌─── QUICK ACTIONS ──────────────────────────────────────────────────────────┐│
│ │                                                                            ││
│ │  [🎯 AI Idea Engine]  [📊 Consultant Studio]  [🗺️ Market Mapper]          ││
│ │                                                                            ││
│ └────────────────────────────────────────────────────────────────────────────┘│
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

### Saved Opportunity States

Each saved opportunity progresses through stages:

```
1. SAVED (Initial State)
   ├─ User has bookmarked opportunity
   ├─ Actions: Add notes, view details, organize
   └─ Next: Move to "Analyzing"

2. ANALYZING
   ├─ User is researching and gathering data
   ├─ Actions: Market analysis, competitor research
   └─ Next: Move to "Planning"

3. PLANNING
   ├─ Building business plan in Consultant Studio
   ├─ Actions: Generate plan, refine strategy
   └─ Next: Move to "Executing"

4. EXECUTING
   ├─ Actively working on launching
   ├─ Actions: Find partners, secure funding, build MVP
   └─ Next: Mark as "Launched" or "Paused"

5. LAUNCHED
   ├─ Business is live
   ├─ Actions: Track progress, analytics
   └─ Archive or continue tracking

6. PAUSED / ARCHIVED
   └─ No longer actively pursuing
```

---

## Consultant Studio: AI-Powered Business Planning

### Entry Points to Consultant Studio

1. **From Saved Opportunity Card:** Click "🚀 Build Plan"
2. **From Workhub Top Nav:** Click "Consultant Studio" tab
3. **From Discovery Card:** Click "Start Business Plan" (saves + redirects)
4. **From Landing Page:** AI Idea Engine → Consultant Studio

### Consultant Studio Interface

```
┌────────────────────── CONSULTANT STUDIO ─────────────────────────┐
│                                                                   │
│ [← Back to Workhub]        Freelance Invoice Tracking  [Save]    │
│                                                                   │
│ ┌─── PROJECT INFO ──────────────────────────────────────────────┐│
│ │ Opportunity: Freelance invoice tracking                       ││
│ │ Score: 89 | Category: MONEY & FINANCE | Status: Planning     ││
│ └───────────────────────────────────────────────────────────────┘│
│                                                                   │
│ ┌─── WORKFLOW TABS ─────────────────────────────────────────────┐│
│ │                                                                ││
│ │  [1. Validate] → [2. Research] → [3. Plan] → [4. Execute]    ││
│ │      ●              ○              ○             ○            ││
│ │                                                                ││
│ └───────────────────────────────────────────────────────────────┘│
│                                                                   │
│ ┌─── STEP 1: VALIDATE OPPORTUNITY ──────────────────────────────┐│
│ │                                                                ││
│ │  🎯 What do you want to validate?                             ││
│ │                                                                ││
│ │  ○ Validate this platform opportunity (Recommended)           ││
│ │     Use OppGrid's validated data as foundation                ││
│ │                                                                ││
│ │  ○ Research a new idea                                        ││
│ │     Start from scratch with your own concept                  ││
│ │                                                                ││
│ │  ○ Find optimal locations for this opportunity                ││
│ │     Geographic analysis and market sizing                     ││
│ │                                                                ││
│ │  [Continue to Validation →]                                   ││
│ │                                                                ││
│ └───────────────────────────────────────────────────────────────┘│
│                                                                   │
│ ┌─── OPPORTUNITY DATA (From OppGrid) ───────────────────────────┐│
│ │                                                                ││
│ │  📊 Platform Intelligence:                                    ││
│ │  • 234 validated user signals                                 ││
│ │  • $50M-$100M market size estimate                            ││
│ │  • 15.3% YoY growth rate                                      ││
│ │  • Medium competition (3-5 players)                           ││
│ │                                                                ││
│ │  🗺️ Geographic Distribution:                                  ││
│ │  • Primary: US National (67% of signals)                      ││
│ │  • Secondary: UK, Canada (28%)                                ││
│ │  • Emerging: Australia (5%)                                   ││
│ │                                                                ││
│ │  [View Full Opportunity Data]                                 ││
│ │                                                                ││
│ └───────────────────────────────────────────────────────────────┘│
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Consultant Studio Workflow

#### STEP 1: Validate Opportunity

**Path A: Validate Platform Opportunity (Recommended)**

```
Claude receives:
├─ OppGrid validated opportunity data (DeepSeek-curated)
├─ 234 user signals across 7 platforms
├─ Geographic distribution data
├─ Market size estimates
└─ Competition analysis

Claude performs:
├─ Web search: Current market conditions
├─ Web search: Existing solutions review
├─ Web search: Recent funding in space
├─ Synthesizes: Platform data + web research
└─ Generates: Validation report

Output:
┌─── VALIDATION REPORT ─────────────────────────┐
│                                                │
│ ✅ OPPORTUNITY VALIDATED                       │
│                                                │
│ Market Opportunity Score: 89/100               │
│                                                │
│ Key Findings:                                  │
│ • Strong demand signals (234 mentions)         │
│ • Growing market (+15.3% YoY)                  │
│ • Addressable pain point                       │
│ • Clear monetization path                      │
│                                                │
│ Risks Identified:                              │
│ • Established competitors (FreshBooks, Wave)   │
│ • Integration complexity (Stripe, banks)       │
│ • Customer acquisition cost concerns           │
│                                                │
│ Recommendation: PROCEED TO BUSINESS PLANNING   │
│                                                │
│ [Continue to Research →]  [Export Report]      │
│                                                │
└────────────────────────────────────────────────┘
```

**Path B: Research New Idea**

```
User Input:
┌──────────────────────────────────────┐
│ Describe your business idea:         │
│                                       │
│ [Text area - user writes idea]       │
│                                       │
│ Target Market:                        │
│ [Freelancers & Contractors]           │
│                                       │
│ Geographic Focus:                     │
│ [US, Canada, UK]                      │
│                                       │
│ [Generate Validation Report →]        │
└──────────────────────────────────────┘

Claude performs:
├─ Search OppGrid platform for related opportunities
├─ Web search: Market research
├─ Web search: Competitor analysis  
├─ Web search: Market trends
└─ Generate comprehensive validation

Output: Similar to Path A, but notes data sources
```

**Path C: Find Optimal Locations**

```
┌─── GEOGRAPHIC MARKET ANALYSIS ────────────────┐
│                                                │
│ Analyzing optimal launch locations for:       │
│ "Freelance invoice tracking platform"         │
│                                                │
│ [Progress] Searching OppGrid signals... ✓     │
│           Analyzing Census data... ⏳          │
│           Mapping competition... ○             │
│           Calculating market density... ○      │
│                                                │
│ [Cancel]                                       │
└────────────────────────────────────────────────┘

Claude performs:
├─ Query DeepSeek: Get geographic signal distribution
├─ Fetch Census Bureau data: Demographics by zip/block
├─ Calculate: Service radius coverage
├─ Map: Demand density vs competition
└─ Rank: Top 20 launch locations

Output:
┌─── TOP LAUNCH LOCATIONS ──────────────────────┐
│                                                │
│ 🥇 Austin, TX (78701-78705)                   │
│    • 12,450 target freelancers                │
│    • Low competition (1 established player)   │
│    • High tech adoption rate (92%)            │
│    • Market size: $2.3M                       │
│    [View Details] [See Map]                   │
│                                                │
│ 🥈 Denver, CO (80202-80206)                   │
│    • 9,890 target freelancers                 │
│    • Medium competition (2 players)           │
│    • Growing market (+18% YoY)                │
│    • Market size: $1.8M                       │
│    [View Details] [See Map]                   │
│                                                │
│ 🥉 Portland, OR (97201-97214)                 │
│    • 8,230 target freelancers                 │
│    • Low competition                          │
│    • High creative industry density           │
│    • Market size: $1.5M                       │
│    [View Details] [See Map]                   │
│                                                │
│ [View All 20 Locations]  [Export to CSV]      │
│                                                │
└────────────────────────────────────────────────┘
```

#### STEP 2: Market Research

```
┌─── STEP 2: MARKET RESEARCH ───────────────────────────────────────┐
│                                                                    │
│ Claude is researching your opportunity...                         │
│                                                                    │
│ ✓ Analyzing platform data (234 signals)                           │
│ ✓ Searching current market conditions                             │
│ ⏳ Reviewing competitor landscape                                  │
│ ○ Gathering industry trends                                       │
│ ○ Analyzing pricing strategies                                    │
│ ○ Researching customer demographics                               │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 40%                       │
│                                                                    │
│ [Working in background... You can navigate away]                  │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

After completion:
┌─── MARKET RESEARCH REPORT ────────────────────────────────────────┐
│                                                                    │
│ 📊 MARKET OVERVIEW                                                 │
│                                                                    │
│ Total Addressable Market (TAM): $850M                             │
│ Serviceable Addressable Market (SAM): $180M                       │
│ Serviceable Obtainable Market (SOM): $12M (Year 1 target)        │
│                                                                    │
│ Market Growth: +15.3% CAGR (2020-2025)                            │
│ Projected Growth: +18% CAGR (2025-2030)                           │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                                                    │
│ 🏆 COMPETITIVE LANDSCAPE                                           │
│                                                                    │
│ Major Players:                                                     │
│ • FreshBooks (Market leader, 35% share, $5.5B valuation)         │
│ • Wave (Free tier, 22% share, acquired by H&R Block)             │
│ • QuickBooks Self-Employed (Intuit, 18% share)                   │
│ • Bonsai (Premium, 8% share, $2M ARR)                            │
│ • Invoice Ninja (Open source, 5% share)                          │
│                                                                    │
│ Competitive Gaps Identified:                                      │
│ ✓ Limited multi-party payment coordination                        │
│ ✓ Poor mobile experience (except FreshBooks)                      │
│ ✓ No intelligent payment follow-up automation                     │
│ ✓ Weak cash flow forecasting                                      │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                                                    │
│ 🎯 TARGET CUSTOMER PROFILE                                         │
│                                                                    │
│ Primary Segment:                                                   │
│ • Freelancers earning $50K-$150K annually                         │
│ • 3-10 active clients at any time                                 │
│ • Age: 28-42 (millennial professionals)                           │
│ • Tech-savvy, mobile-first users                                  │
│ • Willing to pay $15-30/month for time savings                    │
│                                                                    │
│ Pain Points (ranked by severity):                                 │
│ 1. Late payments affecting cash flow (78% mention)                │
│ 2. Manual invoice tracking overhead (65%)                         │
│ 3. Poor visibility into payment status (61%)                      │
│ 4. Inefficient payment follow-up (58%)                            │
│ 5. Difficulty forecasting revenue (52%)                           │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━│
│                                                                    │
│ 💰 PRICING ANALYSIS                                                │
│                                                                    │
│ Competitor Pricing:                                                │
│ • Wave: Free (limited), $16/mo (Pro)                              │
│ • FreshBooks: $15-50/mo (tiered)                                  │
│ • QuickBooks: $15/mo (Self-Employed)                              │
│ • Bonsai: $24-52/mo (premium features)                            │
│                                                                    │
│ Recommended Strategy:                                              │
│ Freemium model with premium at $19-29/mo                          │
│ • Free: 5 invoices/month, basic tracking                          │
│ • Pro ($19/mo): Unlimited invoices, automation                    │
│ • Business ($29/mo): Team features, advanced forecasting          │
│                                                                    │
│ [Continue to Business Plan →]  [Export Research]  [Refine]        │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

#### STEP 3: Generate Business Plan

```
┌─── STEP 3: BUSINESS PLAN GENERATION ──────────────────────────────┐
│                                                                    │
│ Select sections to include in your business plan:                 │
│                                                                    │
│ ✓ Executive Summary                                               │
│ ✓ Market Analysis                                                 │
│ ✓ Competitive Positioning                                         │
│ ✓ Product Strategy                                                │
│ ✓ Go-to-Market Plan                                               │
│ ✓ Financial Projections (3-year)                                  │
│ ✓ Risk Analysis                                                   │
│ ○ Team & Organization (optional)                                  │
│ ○ Technology Stack (optional)                                     │
│ ○ Regulatory Compliance (optional)                                │
│                                                                    │
│ Detail Level: ○ Brief  ● Standard  ○ Comprehensive                │
│                                                                    │
│ Output Format: ☑ PDF  ☑ DOCX  ☐ Google Docs  ☐ Notion            │
│                                                                    │
│ [Generate Business Plan →]                                         │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

Generation Progress:
┌────────────────────────────────────────────────────────────────────┐
│ Generating your business plan...                                   │
│                                                                    │
│ ✓ Executive Summary (287 words)                                   │
│ ✓ Market Analysis (1,243 words)                                   │
│ ⏳ Competitive Positioning (writing...)                            │
│ ○ Product Strategy                                                │
│ ○ Go-to-Market Plan                                               │
│ ○ Financial Projections                                           │
│ ○ Risk Analysis                                                   │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 35%                      │
│                                                                    │
│ Estimated time remaining: 2-3 minutes                             │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

Completion View:
┌─── BUSINESS PLAN COMPLETE ────────────────────────────────────────┐
│                                                                    │
│ ✅ Business Plan Generated Successfully                            │
│                                                                    │
│ Freelance Invoice Tracking Platform                                │
│ 18 pages • 6,234 words • Generated Dec 24, 2025                   │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────────┐│
│ │ EXECUTIVE SUMMARY (Preview)                                    ││
│ │                                                                 ││
│ │ The freelance economy is growing rapidly, with 59 million      ││
│ │ Americans freelancing in 2023 (Upwork). However, freelancers   ││
│ │ consistently struggle with invoice management and payment      ││
│ │ tracking, leading to cash flow uncertainty and administrative  ││
│ │ overhead.                                                       ││
│ │                                                                 ││
│ │ Our platform addresses this $180M market opportunity by        ││
│ │ providing intelligent invoice automation, payment tracking,    ││
│ │ and cash flow forecasting specifically designed for...         ││
│ │                                                                 ││
│ │ [Read More →]                                                   ││
│ └────────────────────────────────────────────────────────────────┘│
│                                                                    │
│ 📑 Sections Included:                                              │
│ • Executive Summary (1 page)                                      │
│ • Market Analysis (3 pages)                                       │
│ • Competitive Positioning (2 pages)                               │
│ • Product Strategy (3 pages)                                      │
│ • Go-to-Market Plan (4 pages)                                     │
│ • Financial Projections (3 pages)                                 │
│ • Risk Analysis (2 pages)                                         │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 📊 FINANCIAL HIGHLIGHTS (Year 1-3 Projection)                 │ │
│ │                                                                │ │
│ │ Year 1: $240K revenue (2,000 users @ $10 avg)                 │ │
│ │ Year 2: $890K revenue (7,500 users @ $9.90 avg)               │ │
│ │ Year 3: $2.1M revenue (15,000 users @ $11.60 avg)             │ │
│ │                                                                │ │
│ │ [View Full Financials →]                                       │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ [📥 Download PDF]  [📥 Download DOCX]  [✏️ Edit Plan]  [🔄 Share] │
│                                                                    │
│ [Continue to Execution Phase →]                                   │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

#### STEP 4: Execution Planning

```
┌─── STEP 4: EXECUTION ROADMAP ─────────────────────────────────────┐
│                                                                    │
│ Your business plan is ready. Now let's help you execute.          │
│                                                                    │
│ ┌─── RECOMMENDED NEXT STEPS ───────────────────────────────────┐ │
│ │                                                               │ │
│ │ 1️⃣ VALIDATE WITH CUSTOMERS (Week 1-2)                        │ │
│ │    • Interview 20 target freelancers                         │ │
│ │    • Test pricing willingness ($15-30/mo range)              │ │
│ │    • Validate core features priority                         │ │
│ │    [Find Interview Leads in OppGrid →]                       │ │
│ │                                                               │ │
│ │ 2️⃣ BUILD MINIMUM VIABLE PRODUCT (Week 3-8)                   │ │
│ │    • Core: Invoice creation + tracking                       │ │
│ │    • Core: Payment status dashboard                          │ │
│ │    • Core: Email reminders                                   │ │
│ │    [Find Technical Co-Founder →]                             │ │
│ │    [Browse Developer Agencies →]                             │ │
│ │                                                               │ │
│ │ 3️⃣ SECURE FUNDING (Parallel to build)                        │ │
│ │    • Target: $50-100K seed funding                           │ │
│ │    • Sources: Angel investors, accelerators, SBA loan        │ │
│ │    [Connect with Investors →]                                │ │
│ │    [Apply to Accelerators →]                                 │ │
│ │                                                               │ │
│ │ 4️⃣ BETA LAUNCH (Week 9-12)                                   │ │
│ │    • Recruit 50-100 beta users                               │ │
│ │    • Gather feedback and iterate                             │ │
│ │    • Refine pricing and positioning                          │ │
│ │    [Access Beta User Leads →]                                │ │
│ │                                                               │ │
│ │ 5️⃣ PUBLIC LAUNCH (Week 13+)                                  │ │
│ │    • Launch marketing campaign                               │ │
│ │    • Target: 100 paid users Month 1                          │ │
│ │    • Scale customer acquisition                              │ │
│ │    [Browse Marketing Agencies →]                             │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌─── RESOURCES YOU'LL NEED ────────────────────────────────────┐ │
│ │                                                               │ │
│ │ 👥 TEAM                                                       │ │
│ │ • Technical Co-Founder or Dev Agency                         │ │
│ │ • Product Designer (UI/UX)                                   │ │
│ │ • Marketing/Growth Lead (later stage)                        │ │
│ │ [Browse Network Hub →]                                       │ │
│ │                                                               │ │
│ │ 💰 FUNDING                                                    │ │
│ │ • Seed: $50-100K (MVP + 6mo runway)                          │ │
│ │ • Series A: $500K-1M (scale marketing)                       │ │
│ │ [Find Investors →] [SBA Loans →]                             │ │
│ │                                                               │ │
│ │ 🎯 CUSTOMERS                                                  │ │
│ │ • Beta Users: 50-100 freelancers                             │ │
│ │ • Launch Cohort: 500 target leads                            │ │
│ │ [Purchase Lead Lists →]                                      │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ [🚀 Move to Active Projects]  [📊 View Full Roadmap]              │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## Execution Phase: From Plan to Launch

### Active Projects Dashboard

When user clicks "Move to Active Projects":

```
┌───────────────────────── ACTIVE PROJECTS ─────────────────────────┐
│                                                                    │
│ [Dashboard]  [Timeline]  [Resources]  [Team]  [Analytics]         │
│                                                                    │
│ ┌─── PROJECT: FREELANCE INVOICE TRACKER ───────────────────────┐ │
│ │                                                               │ │
│ │ Status: 🟡 In Progress  |  Stage: MVP Development            │ │
│ │ Started: Dec 20, 2025   |  Target Launch: Mar 15, 2026       │ │
│ │                                                               │ │
│ │ Progress: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 23%             │ │
│ │                                                               │ │
│ │ ┌─── MILESTONES ────────────────────────────────────────────┐│ │
│ │ │                                                            ││ │
│ │ │ ✅ Business Plan Complete        Dec 24                   ││ │
│ │ │ 🟡 Customer Interviews (8/20)    In Progress              ││ │
│ │ │ ⚪ Technical Co-Founder Found    Jan 15 (target)          ││ │
│ │ │ ⚪ MVP Development Start          Jan 20                  ││ │
│ │ │ ⚪ Beta Launch                    Mar 1                   ││ │
│ │ │ ⚪ Public Launch                  Mar 15                  ││ │
│ │ │                                                            ││ │
│ │ └────────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ │ ┌─── CURRENT TASKS ────────────────────────────────────────┐ │ │
│ │ │                                                            │ │ │
│ │ │ 🔴 HIGH PRIORITY                                          │ │ │
│ │ │ • Complete 12 more customer interviews (Due: Jan 5)       │ │ │
│ │ │ • Review technical co-founder applications (3 pending)    │ │ │
│ │ │ • Finalize MVP feature set based on interviews            │ │ │
│ │ │                                                            │ │ │
│ │ │ 🟡 MEDIUM PRIORITY                                        │ │ │
│ │ │ • Research payment gateway options (Stripe vs Square)     │ │ │
│ │ │ • Draft pitch deck for investors                          │ │ │
│ │ │ • Set up company legal structure (LLC)                    │ │ │
│ │ │                                                            │ │ │
│ │ │ [View All Tasks →]  [Add Task]                            │ │ │
│ │ │                                                            │ │ │
│ │ └────────────────────────────────────────────────────────────┘ │ │
│ │                                                               │ │
│ │ ┌─── RESOURCES CONNECTED ─────────────────────────────────┐  │ │
│ │ │                                                           │  │ │
│ │ │ 👥 Team (2)                                              │  │ │
│ │ │ • You (Founder)                                          │  │ │
│ │ │ • Sarah Chen (Business Consultant) [View Profile]        │  │ │
│ │ │                                                           │  │ │
│ │ │ 💰 Funding ($0 secured / $75K target)                    │  │ │
│ │ │ • Applied: TechStars Austin (pending)                    │  │ │
│ │ │ • Scheduled: 2 angel investor pitches next week          │  │ │
│ │ │                                                           │  │ │
│ │ │ 🎯 Leads (Purchased from OppGrid)                        │  │ │
│ │ │ • Beta User Leads: 150 contacts                          │  │ │
│ │ │ • Interview Candidates: 45 contacts                      │  │ │
│ │ │                                                           │  │ │
│ │ │ [Find More Resources →]                                  │  │ │
│ │ │                                                           │  │ │
│ │ └───────────────────────────────────────────────────────────┘  │ │
│ │                                                               │ │
│ │ [📊 View Analytics]  [✏️ Edit Project]  [👥 Invite Team]     │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌─── QUICK ACTIONS ────────────────────────────────────────────┐ │
│ │                                                               │ │
│ │ [🎯 Find Beta Users]  [💰 Browse Investors]  [👥 Hire Team]  │ │
│ │                                                               │ │
│ │ [📚 Learning Resources]  [🗺️ Market Mapper]  [💬 Community]  │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

### Resource Connection Flow

#### Find Team Members (From Active Project)

```
Click "👥 Hire Team" or "Find Technical Co-Founder"
        ↓
Navigate to: "Find Expert Help" tab
        ↓
┌─── FIND EXPERT HELP ──────────────────────────────────────────────┐
│                                                                    │
│ Looking for: [Technical Co-Founder ▾]                             │
│ Industry: [FinTech / SaaS ▾]                                       │
│ Location: [US - Remote OK ▾]                                       │
│ Budget: [$0 - Equity only ▾]                                       │
│                                                                    │
│ [Search Network →]                                                 │
│                                                                    │
│ ┌─── MATCHING PROFILES (24) ───────────────────────────────────┐ │
│ │                                                               │ │
│ │ ┌───────────────────────────────────────────────────────────┐│ │
│ │ │ 👤 Alex Rodriguez - Senior Full-Stack Engineer           ││ │
│ │ │                                                            ││ │
│ │ │ 🏅 92% Match to your needs                                ││ │
│ │ │                                                            ││ │
│ │ │ Experience:                                                ││ │
│ │ │ • 8 years full-stack (Node.js, React, PostgreSQL)         ││ │
│ │ │ • Previously built 2 payment platforms                    ││ │
│ │ │ • Co-founded fintech startup (acquired 2023)              ││ │
│ │ │                                                            ││ │
│ │ │ Looking for:                                               ││ │
│ │ │ • CTO role with equity                                     ││ │
│ │ │ • Fintech / SaaS space                                     ││ │
│ │ │ • Remote, US-based team                                    ││ │
│ │ │                                                            ││ │
│ │ │ Availability: Immediately                                  ││ │
│ │ │ Location: Austin, TX (Remote)                              ││ │
│ │ │                                                            ││ │
│ │ │ [View Full Profile]  [Request Introduction]  [Save]       ││ │
│ │ └───────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ │ [Load More Profiles...]                                       │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

After "Request Introduction":
┌─────────────────────────────────────────────────────────────────┐
│ Request Introduction to Alex Rodriguez                          │
│                                                                 │
│ Your project: Freelance Invoice Tracker                        │
│                                                                 │
│ Message to Alex:                                                │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ Hi Alex,                                                     ││
│ │                                                              ││
│ │ I'm building a freelance invoice tracking platform and      ││
│ │ looking for a technical co-founder. Your experience with    ││
│ │ payment platforms and fintech is exactly what we need.      ││
│ │                                                              ││
│ │ Would love to discuss the opportunity. Here's our business  ││
│ │ plan: [Auto-attached]                                        ││
│ │                                                              ││
│ │ Best,                                                        ││
│ │ [Your Name]                                                  ││
│ │                                                              ││
│ └─────────────────────────────────────────────────────────────┘│
│                                                                 │
│ Attachments:                                                    │
│ ✓ Business Plan PDF                                            │
│ ✓ Financial Projections                                        │
│ ○ Add pitch deck                                               │
│                                                                 │
│ [Cancel]  [Send Introduction Request]                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Find Funding (From Active Project)

```
Click "💰 Browse Investors" or Navigate to "Find Money" tab
        ↓
┌─── FIND MONEY ────────────────────────────────────────────────────┐
│                                                                    │
│ Funding Stage: [Seed ▾]                                            │
│ Amount Needed: [$50K-$100K ▾]                                      │
│ Industry: [FinTech ▾]                                              │
│ Location: [US ▾]                                                   │
│                                                                    │
│ [Search Investors →]                                               │
│                                                                    │
│ ┌─── INVESTOR MATCHES (47) ────────────────────────────────────┐ │
│ │                                                               │ │
│ │ [Angel Investors]  [VCs]  [Accelerators]  [Alternative]      │ │
│ │                                                               │ │
│ │ ┌───────────────────────────────────────────────────────────┐│ │
│ │ │ 🏢 Austin Ventures - Seed Fund                            ││ │
│ │ │                                                            ││ │
│ │ │ 🎯 88% Match to your needs                                ││ │
│ │ │                                                            ││ │
│ │ │ Investment Range: $25K-$150K                               ││ │
│ │ │ Focus: B2B SaaS, FinTech, Austin-based                    ││ │
│ │ │ Portfolio: 34 companies (8 exits)                          ││ │
│ │ │ Notable: PaySimple (acq. EverCommerce $1.1B)              ││ │
│ │ │                                                            ││ │
│ │ │ Recent Investments:                                        ││ │
│ │ │ • Payment processing for contractors ($75K seed)           ││ │
│ │ │ • Freelancer time tracking app ($100K seed)                ││ │
│ │ │                                                            ││ │
│ │ │ Application Status: Open (Next deadline: Jan 31)          ││ │
│ │ │                                                            ││ │
│ │ │ [View Full Profile]  [Apply for Funding]  [Save]          ││ │
│ │ └───────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ │ ┌───────────────────────────────────────────────────────────┐│ │
│ │ │ 🚀 Y Combinator - W26 Batch                               ││ │
│ │ │                                                            ││ │
│ │ │ Investment: $500K for 7% equity                            ││ │
│ │ │ Application Deadline: Jan 10, 2026                         ││ │
│ │ │ Program Duration: 3 months (Mar-May 2026)                  ││ │
│ │ │                                                            ││ │
│ │ │ Perfect for: Early-stage SaaS, proven traction            ││ │
│ │ │ Demo Day: May 2026 (access to top VCs)                     ││ │
│ │ │                                                            ││ │
│ │ │ [Learn More]  [Start Application]  [Save]                 ││ │
│ │ └───────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ │ [Load More...]                                                │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌─── ALTERNATIVE FUNDING ──────────────────────────────────────┐ │
│ │                                                               │ │
│ │ 🏦 SBA Microloans ($0-$50K)                                   │ │
│ │    Low interest, business-friendly terms                     │ │
│ │    [Learn More →]                                             │ │
│ │                                                               │ │
│ │ 💳 Revenue-Based Financing                                    │ │
│ │    Get funding now, repay % of revenue                       │ │
│ │    [Browse Options →]                                         │ │
│ │                                                               │ │
│ │ 👥 Crowdfunding (Kickstarter, Republic)                      │ │
│ │    Pre-sell product to fund development                      │ │
│ │    [Explore Platforms →]                                      │ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

#### Purchase Lead Lists

```
Navigate to "Leads" tab
        ↓
┌─── LEADS MARKETPLACE ─────────────────────────────────────────────┐
│                                                                    │
│ Find validated leads from OppGrid's opportunity data              │
│                                                                    │
│ For Opportunity: [Freelance Invoice Tracker ▾]                    │
│                                                                    │
│ Lead Type: [Beta Users ▾]                                          │
│            [Early Adopters | Interview Candidates | Partners]     │
│                                                                    │
│ ┌─── AVAILABLE LEAD PACKAGES ──────────────────────────────────┐ │
│ │                                                               │ │
│ │ ┌───────────────────────────────────────────────────────────┐│ │
│ │ │ 📦 BETA USER LEAD PACKAGE                                 ││ │
│ │ │                                                            ││ │
│ │ │ 150 verified freelancers actively seeking invoice tools   ││ │
│ │ │                                                            ││ │
│ │ │ Includes:                                                  ││ │
│ │ │ • Full contact info (email + LinkedIn)                    ││ │
│ │ │ • Income range ($50K-$150K verified)                       ││ │
│ │ │ • Current tools used (competitor intel)                    ││ │
│ │ │ • Pain point severity score                                ││ │
│ │ │ • Geographic distribution                                  ││ │
│ │ │ • Best time to contact                                     ││ │
│ │ │                                                            ││ │
│ │ │ Quality Score: 89/100 (GOLDMINE tier)                     ││ │
│ │ │ Freshness: Updated 3 days ago                              ││ │
│ │ │                                                            ││ │
│ │ │ Price: $299  [Business Tier: $199]                        ││ │
│ │ │                                                            ││ │
│ │ │ [Preview Sample (10 leads)]  [Purchase Package]           ││ │
│ │ └───────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ │ ┌───────────────────────────────────────────────────────────┐│ │
│ │ │ 📦 CUSTOMER INTERVIEW PACKAGE                             ││ │
│ │ │                                                            ││ │
│ │ │ 45 freelancers willing to participate in paid interviews  ││ │
│ │ │                                                            ││ │
│ │ │ Includes:                                                  ││ │
│ │ │ • Contact info with preferred interview method            ││ │
│ │ │ • Current invoice management approach                      ││ │
│ │ │ • Top 3 pain points (pre-screened)                         ││ │
│ │ │ • Willingness-to-pay indicators                            ││ │
│ │ │ • Interview availability calendar                          ││ │
│ │ │                                                            ││ │
│ │ │ Price: $149  [Pro Tier: $99]                              ││ │
│ │ │                                                            ││ │
│ │ │ [Preview Sample]  [Purchase Package]                      ││ │
│ │ └───────────────────────────────────────────────────────────┘│ │
│ │                                                               │ │
│ └───────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ [View All Lead Packages →]                                         │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

After Purchase:
┌─────────────────────────────────────────────────────────────────┐
│ ✅ Beta User Lead Package Purchased                             │
│                                                                 │
│ 150 leads ready for download                                   │
│                                                                 │
│ [📥 Download CSV]  [📧 Send to Email]  [🔗 CRM Integration]    │
│                                                                 │
│ Connected to Active Project:                                   │
│ "Freelance Invoice Tracker" → Leads (150)                      │
│                                                                 │
│ [Go to Project Dashboard]                                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Navigation & State Management

### Global Navigation (Authenticated Users)

```
┌────────────────────────────────────────────────────────────────┐
│                                                                │
│ [OppGrid Logo]                                    [Leon ▾]    │
│                                                                │
│ [Discover] [Build *] [Find Help] [Find Money] [Leads] [Manage]│
│              ↑                                                 │
│         Badge: (3)                                             │
│     3 active items                                             │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

**Badge Indicators:**
- **Discover:** No badge (browse mode)
- **Build:** Shows count of (Saved opportunities + Active projects)
  - Example: `Build (12)` = 9 saved + 3 active projects
- **Find Help:** Shows pending connection requests
- **Find Money:** Shows active funding applications
- **Leads:** No badge
- **Manage:** Shows pending actions (payment due, profile incomplete)

### State Persistence

**User's Complete State:**
```javascript
{
  user_id: "usr_123",
  tier: "pro",
  
  // Discovery State
  discovery: {
    filters: {
      categories: ["MONEY & FINANCE", "HOME & GARDEN"],
      score_threshold: 80,
      competition: ["low", "medium"]
    },
    saved_searches: [...],
    recently_viewed: [...]
  },
  
  // Workhub State
  workhub: {
    collections: [
      {
        id: "col_001",
        name: "My Ideas",
        opportunities: [
          {
            id: "opp_123",
            status: "saved",  // saved | analyzing | planning | executing
            tags: ["saas", "fintech"],
            notes: "Check competitor pricing",
            consultant_studio_session: {
              step: "validation",  // validation | research | plan | execute
              data: {...}
            }
          }
        ]
      }
    ],
    active_projects: [
      {
        id: "proj_456",
        opportunity_id: "opp_123",
        status: "mvp_development",
        team: [...],
        funding: {...},
        milestones: [...]
      }
    ]
  },
  
  // Connections
  network: {
    team_members: [...],
    investors: [...],
    consultants: [...]
  },
  
  // Purchases
  leads_purchased: [...],
  unlocked_opportunities: [...]
}
```

### Cross-Page Context Passing

**Scenario: User clicks "🚀 Start Business Plan" from Discovery Card**

```
1. Discovery Card (opp_123)
   ↓
   User clicks "Start Business Plan"
   ↓
   
2. System Actions:
   - Save opportunity to Workhub (if not already saved)
   - Create Consultant Studio session
   - Pass opportunity data to Studio
   ↓
   
3. Navigate to: /build/consultant-studio?opp=opp_123&step=validate
   ↓
   
4. Consultant Studio loads:
   - Pre-populated with opportunity data
   - Auto-starts at Step 1: Validate
   - Shows "Analyzing platform opportunity (recommended)" path
   ↓
   
5. User completes workflow → Business plan generated
   ↓
   
6. Auto-update Workhub:
   - Opportunity status: saved → planning
   - Add business plan document to project
   - Show "Continue to Execution" CTA
```

---

## Technical Implementation

### API Endpoints

```python
# Discovery to Workhub
POST /api/opportunities/{id}/save
GET /api/workhub/collections
POST /api/workhub/collections/{id}/add
PUT /api/workhub/opportunities/{id}/status

# Consultant Studio
POST /api/consultant-studio/sessions
GET /api/consultant-studio/sessions/{id}
PUT /api/consultant-studio/sessions/{id}/step
POST /api/consultant-studio/validate  # Claude API call
POST /api/consultant-studio/research  # Claude + Web Search
POST /api/consultant-studio/generate-plan  # Claude
GET /api/consultant-studio/sessions/{id}/export  # PDF/DOCX

# Active Projects
POST /api/projects
GET /api/projects/{id}
POST /api/projects/{id}/milestones
POST /api/projects/{id}/tasks
PUT /api/projects/{id}/status

# Resources
GET /api/network/experts?role=technical_cofounder
POST /api/network/connections/request
GET /api/funding/investors?stage=seed&amount=50000-100000
POST /api/funding/applications

# Leads
GET /api/leads/packages?opportunity_id={id}
POST /api/leads/purchase
GET /api/leads/downloads/{id}
```

### State Machine: Opportunity Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                    OPPORTUNITY LIFECYCLE                        │
│                                                                 │
│  DISCOVERED (on platform)                                       │
│      ↓                                                          │
│      └─→ [User Saves] ─→ SAVED (in Workhub collection)         │
│                            ↓                                    │
│                            ├─→ [Add notes, tag] ─→ SAVED       │
│                            │                                    │
│                            └─→ [Start analysis] ─→ ANALYZING   │
│                                   ↓                             │
│                                   ├─→ [Research market]         │
│                                   │                             │
│                                   └─→ [Build plan] ─→ PLANNING  │
│                                          ↓                      │
│                                          ├─→ [Generate BP]      │
│                                          │                      │
│                                          └─→ [Start exec]       │
│                                               ↓                 │
│                                          EXECUTING              │
│                                               ↓                 │
│                                          ├─→ LAUNCHED           │
│                                          ├─→ PAUSED             │
│                                          └─→ ARCHIVED           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Database Schema

```sql
-- Collections
CREATE TABLE workhub_collections (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  name VARCHAR(100),
  description TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

-- Saved Opportunities
CREATE TABLE workhub_opportunities (
  id UUID PRIMARY KEY,
  collection_id UUID REFERENCES workhub_collections(id),
  opportunity_id UUID REFERENCES opportunities(id),
  status VARCHAR(50),  -- saved, analyzing, planning, executing
  tags TEXT[],
  notes TEXT,
  saved_at TIMESTAMP,
  last_activity TIMESTAMP
);

-- Consultant Studio Sessions
CREATE TABLE consultant_studio_sessions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  opportunity_id UUID REFERENCES opportunities(id),
  current_step VARCHAR(50),  -- validate, research, plan, execute
  validation_data JSONB,
  research_data JSONB,
  business_plan_data JSONB,
  execution_data JSONB,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

-- Active Projects
CREATE TABLE projects (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  opportunity_id UUID REFERENCES opportunities(id),
  name VARCHAR(200),
  status VARCHAR(50),
  stage VARCHAR(50),  -- validation, mvp, beta, launch
  progress_percentage INT,
  target_launch_date DATE,
  created_at TIMESTAMP
);

-- Project Milestones
CREATE TABLE project_milestones (
  id UUID PRIMARY KEY,
  project_id UUID REFERENCES projects(id),
  title VARCHAR(200),
  description TEXT,
  status VARCHAR(50),  -- pending, in_progress, complete
  due_date DATE,
  completed_at TIMESTAMP
);

-- Network Connections
CREATE TABLE network_connections (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  project_id UUID REFERENCES projects(id),
  connection_type VARCHAR(50),  -- expert, partner, investor
  connection_id UUID,  -- References profiles table
  status VARCHAR(50),  -- requested, connected, declined
  created_at TIMESTAMP
);
```

---

## Summary: Complete User Flow

```
1. DISCOVERY
   User browses opportunity cards in "Discover" tab
   ↓
   Finds interesting opportunity
   ↓
   
2. BOOKMARK
   Clicks "💾 Save to Workhub"
   ↓
   Opportunity added to collection
   ↓
   Badge appears: Build (1)
   ↓
   
3. WORKHUB ENTRY
   Click "Build" tab
   ↓
   See saved opportunity in "My Ideas" collection
   ↓
   Click "🚀 Build Plan"
   ↓
   
4. CONSULTANT STUDIO (Planning)
   Step 1: Validate opportunity (Claude + platform data)
   Step 2: Research market (Claude web search + OppGrid intel)
   Step 3: Generate business plan (Claude synthesis)
   Step 4: Execution roadmap
   ↓
   Business plan PDF generated
   ↓
   
5. ACTIVE PROJECT
   Click "Move to Active Projects"
   ↓
   Project dashboard created
   ↓
   Milestones, tasks, progress tracking enabled
   ↓
   
6. RESOURCE CONNECTION
   Find Team:    "Find Help" tab → Browse experts → Request intro
   Find Funding: "Find Money" tab → Browse investors → Apply
   Find Leads:   "Leads" tab → Purchase lead lists → Download CSV
   ↓
   
7. EXECUTION & LAUNCH
   Track progress in Active Projects
   ↓
   Mark milestones complete
   ↓
   Update status: EXECUTING → LAUNCHED
   ↓
   
8. POST-LAUNCH
   Analytics tracking (future feature)
   ↓
   Mark as "Launched" or "Paused"
   ↓
   Archive or continue tracking
```

---

## Next Steps for Implementation

### Phase 1: Core Workhub (Week 1-2)
1. Build Collections system (save, organize, tag)
2. Opportunity state management (saved → analyzing → planning)
3. Workhub dashboard UI
4. Integration with existing Discovery cards

### Phase 2: Consultant Studio (Week 3-4)
1. 4-step workflow interface
2. Claude integration for validation, research, planning
3. DeepSeek integration for platform data queries
4. Document generation (PDF/DOCX export)

### Phase 3: Active Projects (Week 5)
1. Project creation from Consultant Studio
2. Milestone and task management
3. Progress tracking dashboard
4. Resource connection system

### Phase 4: Resource Integration (Week 6)
1. Network Hub integration (Find Help)
2. Funding platform integration (Find Money)
3. Leads marketplace integration
4. Cross-platform state synchronization

---

**End of Document**
