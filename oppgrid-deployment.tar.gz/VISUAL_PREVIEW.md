# Discovery Feed - Visual Preview
**What the completed feature looks like**

---

## 📱 Full Page Layout

```
┌────────────────────────────────────────────────────────────────┐
│  [O] OppGrid    Discover  Saved  Hub  Experts     [Profile]    │ ← Navbar (sticky)
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│                                                                  │
│  Discover Validated Opportunities                               │ ← Hero
│  Browse real-world problems validated by the community          │
│                                                                  │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  💡 Recommended for You                        [View All →]    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ 🔥 HOT       │  │ 🔥 HOT       │  │ ⚡ FRESH     │        │
│  │ Freelance    │  │ Parking in   │  │ Subscription │        │
│  │ Invoicing... │  │ Cities...    │  │ Management...│        │
│  │              │  │              │  │              │        │
│  │ ✅ 92% Match │  │ ✅ 88% Match │  │ ✅ 85% Match │        │
│  │ 🟢 82 Score  │  │ 🟢 76 Score  │  │ 🟡 69 Score  │        │
│  │ 445 valid.   │  │ 312 valid.   │  │ 189 valid.   │        │
│  │ [Validate]   │  │ [Validate]   │  │ [Validate]   │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
│                                                                  │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  🔍 Search opportunities...                    [🔍 Search]      │
│                                                                  │
│  Category: [All ▼]  Feasibility: [Any ▼]  Location: [Any ▼]   │
│  Sort: [Highest Feasibility ▼]            [💾 Save Search]     │
│                                                                  │
│  Active: [Tech ×] [Local ×] [High Feasibility ×] [Clear All]  │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  432 opportunities found                    [Grid ⊞] [List ☰]  │
└────────────────────────────────────────────────────────────────┘

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ ☐                │  │ ☐                │  │ ☐                │
│ 💼 Work & Prod.  │  │ 💰 Finance       │  │ 🏥 Health        │
│                  │  │                  │  │                  │
│ Freelance        │  │ Investment       │  │ Finding Doctors  │
│ invoicing is a   │  │ Portfolio...     │  │ Who Accept...    │
│ nightmare        │  │                  │  │                  │
│                  │  │                  │  │                  │
│ "Managing        │  │ "Tracking my     │  │ "Insurance      │
│  invoices takes  │  │  investments..." │  │  networks are..." │
│  15% of my..."   │  │                  │  │                  │
│                  │  │                  │  │                  │
│ ┌──────────────┐ │  │ ┌──────────────┐ │  │ ┌──────────────┐ │
│ │Feasibility 82│ │  │ │Feasibility 76│ │  │ │Feasibility 69│ │
│ │█████████░░░░ │ │  │ │████████░░░░░ │ │  │ │███████░░░░░░ │ │
│ └──────────────┘ │  │ └──────────────┘ │  │ └──────────────┘ │
│                  │  │                  │  │                  │
│ 📊 445 valid.    │  │ 📊 312 valid.    │  │ 📊 189 valid.    │
│ 🔥 +18% (7d)     │  │ 🔥 +12% (7d)     │  │ 🔥 +5% (7d)      │
│ 💰 $100M-$500M   │  │ 💰 $50M-$100M    │  │ 💰 $500M+        │
│ 🌍 International │  │ 🌍 National      │  │ 🌍 Local         │
│ ⏱ 45 days old    │  │ ⏱ 23 days old    │  │ ⏱ 67 days old    │
│                  │  │                  │  │                  │
│ [✓ Validate]     │  │ [✓ Validate]     │  │ [✓ Validate]     │
│ [💾 Save]        │  │ [💾 Save]        │  │ [💾 Save]        │
│ [🤖 Analyze]     │  │ [🤖 Analyze]     │  │ [🤖 Analyze]     │
│ [↗ Share]        │  │ [↗ Share]        │  │ [↗ Share]        │
│                  │  │                  │  │                  │
│ 👥 "5 users with │  │ 👥 "3 investors  │  │ 👥 "12 users in  │
│     your skillset│  │     watching"    │  │     healthcare"  │
│     validated"   │  │                  │  │                  │
└──────────────────┘  └──────────────────┘  └──────────────────┘

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ ... 3 more rows of cards (total 12 on page 1)                  │
└──────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  [← Previous]  Page 1 of 36 (showing 1-12 of 432)  [Next →]   │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  Compare Selected (2/3):  [Opp #1] [Opp #4]  [Compare →]      │ ← Floating panel
└────────────────────────────────────────────────────────────────┘
```

---

## 🎨 Color Scheme (Stone Palette)

```
Background:     #FAFAF9 (stone-50)
Cards:          #FFFFFF (white)
Text Primary:   #1C1917 (stone-900)
Text Secondary: #78716C (stone-500)
Borders:        #E7E5E4 (stone-200)
Accent:         #D97757 (terracotta)
```

---

## 🎭 Hover States

**Before Hover:**
```
┌──────────────────┐
│ Freelance        │
│ invoicing...     │
│                  │
│ Feasibility: 82  │
│ 445 validations  │
└──────────────────┘
```

**On Hover:**
```
┌──────────────────┐  ← Card elevates (shadow increases)
│ Freelance        │  ← Border highlights (accent color)
│ invoicing...     │
│                  │
│ Feasibility: 82  │
│ 445 validations  │
│                  │
│ ┌──────────────┐ │  ← Quick actions fade in
│ │[✓] [💾] [🤖]│ │
│ └──────────────┘ │
└──────────────────┘
```

---

## 🎉 Validation Animation

**Click "Validate" button:**
```
Step 1: Button changes
[Validate] → [✓ Validated] (green)

Step 2: Confetti animation
     ✨
   🎊 🎉 🎊
 ✨   🎉   ✨
🎊 Freelance 🎊
   invoicing
     ✨🎉✨

Step 3: Count updates
445 validations → 446 validations (+1)

Duration: 2 seconds total
```

---

## 📊 Comparison Modal

**When user clicks "Compare" (2-3 cards selected):**

```
┌──────────────────────────────────────────────────────────┐
│  Opportunity Comparison                        [× Close]  │
├──────────────────────────────────────────────────────────┤
│                                                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │ Freelance   │  │ Investment  │  │ Finding     │      │
│  │ Invoicing   │  │ Portfolio   │  │ Doctors     │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │ Feasibility │  │ Feasibility │  │ Feasibility │      │
│  │     82      │  │     76      │  │     69      │      │
│  │   🟢 HIGH   │  │  🟡 MEDIUM  │  │  🟡 MEDIUM  │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │ Validations │  │ Validations │  │ Validations │      │
│  │     445     │  │     312     │  │     189     │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │ Growth Rate │  │ Growth Rate │  │ Growth Rate │      │
│  │   +18.9%    │  │   +12.3%    │  │    +5.1%    │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │Market Size  │  │Market Size  │  │Market Size  │      │
│  │ $100M-500M  │  │  $50M-100M  │  │   $500M+    │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │  Location   │  │  Location   │  │  Location   │      │
│  │International│  │  National   │  │    Local    │      │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤      │
│  │     Age     │  │     Age     │  │     Age     │      │
│  │  45 days    │  │  23 days    │  │  67 days    │      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
│                                                            │
│  🏆 Winner: Freelance Invoicing                           │
│  (Highest overall score: 82)                              │
│                                                            │
│  [View Full Details]  [Export Comparison (PDF)]          │
│                                                            │
└──────────────────────────────────────────────────────────┘
```

---

## 💾 Save Search Modal

**When user clicks "Save Search":**

```
┌────────────────────────────────────────────────────┐
│  Save This Search                        [× Close] │
├────────────────────────────────────────────────────┤
│                                                     │
│  Current Filters:                                  │
│  • Category: Technology                            │
│  • Feasibility: High (75+)                         │
│  • Location: Local                                 │
│  • Sort: Highest Feasibility                       │
│                                                     │
│  Search Name:                                      │
│  [High-Potential Tech (Local)________________]     │
│                                                     │
│  Notify me when new opportunities match:           │
│                                                     │
│  ☑ Email notifications                             │
│    ○ Instant (as they appear)                      │
│    ● Daily digest (8:00 AM) ← Selected            │
│                                                     │
│  ☑ Push notifications                              │
│    ● Instant                                       │
│                                                     │
│  ☐ Slack messages (Premium)                        │
│                                                     │
│  ℹ️  Free tier: 1 saved search                    │
│     Upgrade to Pro for 10 saved searches          │
│                                                     │
│  [Cancel]                    [Save Search]         │
│                                                     │
└────────────────────────────────────────────────────┘
```

---

## 🎯 Time-Decay Access Badges

**Badges appear on each card based on opportunity age:**

```
🔥 HOT (0-7 days)
- Red/orange badge
- Enterprise tier unlocked immediately
- Highest value opportunities

⚡ FRESH (8-30 days)
- Yellow badge  
- Business tier unlocked at 8+ days
- Still high demand

✓ VALIDATED (31-90 days)
- Green badge
- Pro tier unlocked at 31+ days
- Proven market fit

📚 ARCHIVE (91+ days)
- Gray badge
- Free tier unlocked at 91+ days
- Historical opportunities
```

---

## 📱 Mobile View (Responsive)

**Mobile (< 768px):**
```
┌─────────────────┐
│ [☰] OppGrid  [👤]│ ← Hamburger menu
├─────────────────┤
│                 │
│ Recommended ▼   │ ← Collapsible
│ [Card 1]        │
│ [Card 2]        │
│                 │
│ [🔍 Filters]    │ ← Opens modal
│                 │
│ ┌─────────────┐ │
│ │ Opportunity │ │ ← 1 column
│ │ Card #1     │ │
│ └─────────────┘ │
│ ┌─────────────┐ │
│ │ Opportunity │ │
│ │ Card #2     │ │
│ └─────────────┘ │
│                 │
│ [Load More]     │
│                 │
└─────────────────┘
```

---

## 🎨 Component Breakdown

**Page structure:**
```tsx
<Discover>
  <Navbar />
  <Hero />
  <RecommendedSection>
    <OpportunityCard />  // 3-9 cards
  </RecommendedSection>
  <FilterBar>
    <SearchInput />
    <FilterDropdowns />
    <ActiveFilterPills />
  </FilterBar>
  <OpportunityGrid>
    <OpportunityCard />  // 12 cards per page
    <OpportunityCard />
    ...
  </OpportunityGrid>
  <Pagination />
  {selectedCards.length > 0 && <ComparisonPanel />}
  {showModal && <ComparisonModal />}
  {showSaveSearch && <SavedSearchModal />}
</Discover>
```

---

## 🚀 What You Get

**Visual Features:**
- ✨ Smooth animations (fade-in, hover, confetti)
- 🎨 Professional Stone color palette
- 📱 Fully responsive (mobile → desktop)
- ♿ Accessible (ARIA labels, keyboard nav)
- ⚡ Fast (optimistic updates, no reload)
- 🎯 Modern UI (Tailwind-inspired)

**Functional Features:**
- 🔍 Real-time search (debounced)
- 🎛️ 8 filter types
- ⚖️ Side-by-side comparison (max 3)
- 💾 Saved searches with alerts
- 🤖 AI-powered recommendations
- 📊 Match score badges
- 👥 Social proof indicators
- 🎉 Validation animations

---

**This is what will appear at `/discover` once deployed to Replit!**
